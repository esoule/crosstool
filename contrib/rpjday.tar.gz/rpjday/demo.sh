#!/bin/sh

# set -ex

eval \
	`cat ./sw.dat` \
	`cat ./arch_data_files/powerpc-750.dat` \
	sh btc.sh \
		--unpackandpatch \
		--preparekernelheaders \
		--buildbinutils \
		--installglibcheaders \
		--buildgcccore \
		--buildglibc \
		--buildgcc
		
